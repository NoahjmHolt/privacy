NAME OF PROJECT:
================
Homework 3: Encryption and Decryption of a file using OpenSSL and AE-256


NAME OF PROGRAMMER:
===================
Noah Holt


STATEMENT:
==========
I have neither given nor received unauthorized assistance on this work.


SPECIAL INSTRUCTIONS:
=====================

Describe where the files can be found.

Describe each file and the purpose it serves.

Provide any special instructions to access or run your program.


PROBLEM DESCRIPTION AND REMEDIATION:
====================================

1) Install OpenSSL Y
2) Use AES-256 algo in CBC mode Y
3) Make IVs
